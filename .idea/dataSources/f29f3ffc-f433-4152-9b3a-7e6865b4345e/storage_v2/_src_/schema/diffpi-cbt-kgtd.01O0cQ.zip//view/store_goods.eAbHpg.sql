create view store_goods as
  select `msg`.`id`             AS `id`,
         `msg`.`store_id`       AS `store_id`,
         `msg`.`g_id`           AS `g_id`,
         `msg`.`GoodsID`        AS `GoodsID`,
         `msg`.`promPrice`      AS `promPrice`,
         `msg`.`activity_price` AS `activity_price`,
         `msg`.`vip_price`      AS `vip_price`,
         `msg`.`UnitName`       AS `UnitName`,
         `msg`.`count`          AS `count`,
         `msg`.`update_date`    AS `update_date`,
         `msg`.`create_date`    AS `create_date`,
         `ms`.`shop_id`         AS `shop_id`,
         `mg`.`BarcodeID`       AS `BarcodeID`
  from ((`diffpi-cbt-kgtd`.`module_store_goods` `msg` left join `diffpi-cbt-kgtd`.`module_goods` `mg` on ((`msg`.`g_id`
                                                                                                           =
                                                                                                           `mg`.`id`))) left join `diffpi-cbt-kgtd`.`module_store` `ms` on ((
    `ms`.`id` = `msg`.`store_id`)));

